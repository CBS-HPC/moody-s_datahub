# Moody's Datahub

`moodys_datahub` is a Python package for selecting, downloading, and processing
Moody's DataHub exports over SFTP. It is designed for large table exports and
supports parallel download and processing workflows for CSV, Parquet, ORC, and
Avro datasets.

## Main functionality

The package is built around the `Sftp` class and supports the main DataHub
workflow end to end:

- connect to a Moody's DataHub SFTP server or a local export repository
- inspect available data products and tables
- select a product, table, and output columns
- filter by layered BvD clauses, exact BvD ID lists, country-code prefixes, and time periods
- download missing files to a local cache
- process large exports with an explicit pandas pipeline, an explicit Polars
  pipeline, or an auto-selecting wrapper that returns pandas
- run helper workflows such as indexed RapidFuzz company-name matching, BvD
  change tracking, and Orbis-to-DataHub column mapping

## Typical workflow

### Interactive notebook workflow

```python
from moodys_datahub import Sftp

SFTP = Sftp(privatekey="user_provided-ssh-key.pem")
SFTP.select_data()
SFTP.define_options()
SFTP.select_columns()
SFTP.bvd_list = ["DK28505116", "SE5567031702"]

df, files = SFTP.process_all()
```

### Direct setup workflow

```python
from moodys_datahub import Sftp

SFTP = Sftp(privatekey="user_provided-ssh-key.pem")
SFTP.set_data_product = "Firmographics (Monthly)"
SFTP.set_table = "bvd_id_and_name"
SFTP.select_cols = ["bvd_id_number", "name"]
SFTP.bvd_list = ["DK28505116", "SE5567031702"]

df, files = SFTP.polars_all()
```

Use `select_data()` when you want the interactive widget-based flow in notebook
environments. Use `set_data_product` and `set_table` when you want a fully
scripted workflow.

For batch jobs, disable interactive prompts and set a download cache root:

```python
SFTP = Sftp(
    privatekey="user_provided-ssh-key.pem",
    interactive=False,
    server_cleanup=False,
    download_root="/scratch/moody_datahub",
    output_root="/scratch/moody_results",
)
SFTP.set_data_product = "Firmographics (Monthly)"
SFTP.set_table = "bvd_id_and_name"

report = SFTP.process_all(dry_run=True)
if report.ok:
    df, files = SFTP.process_all()
```

When `download_root` is not set, downloaded files use the existing default
relative path: `Data Products/<data_product>/<table>`. When it is set, only the
root is replaced: `<download_root>/<data_product>/<table>`.

When `output_root` is set, auto-generated processed outputs are written below
that root. Explicit `destination` values in `process_all()` still take
precedence and keep the existing behavior.

## Processing backends

Use `process_all()` as the default high-level API. It auto-selects the backend
and always returns a pandas `DataFrame` together with `file_names`.

Use `pandas_all()` when you need pandas semantics explicitly, especially for
string queries and pandas-oriented callables.

Use `polars_all()` when you want the native Polars pipeline and native Polars
return type. The current Polars path supports:

- exact BvD ID filtering
- prefix or country-code BvD filtering
- multi-column BvD membership checks
- layered `AND_bvd_list` / `OR_bvd_list` filtering
- year-based `time_period` filtering
- `pl.Expr` filters

After any `process_all()` call, inspect `SFTP.last_process_engine` and
`SFTP.last_process_reason` to see which backend was used and why.

`process_all()` routes to pandas when you use:
- string queries
- pandas-only callables
- `concat_files=False`
- custom `pool_method` or `n_batches`
- unsupported or mixed file formats

### Backend inspection example

```python
df, files = SFTP.process_all()

print(SFTP.last_process_engine)  # "polars" or "pandas"
print(SFTP.last_process_reason)  # e.g. "compatible" or "string_query"
```

## API highlights

The stable public API is centered on `moodys_datahub.Sftp`:

- session setup: `Sftp(...)`, `download_root`, `output_root`, `interactive`,
  `offline`, `tables_available()`, `set_data_product`, `set_table`,
  `select_data()`
- filtering: `select_cols`, `select_columns()`, `bvd_list`, `AND_bvd_list`,
  `OR_bvd_list`, `time_period`
- processing: `process_one()`, `process_all(dry_run=True)`, `pandas_all()`,
  `polars_all()`, `download_all(dry_run=True)`, `profile_table()`,
  `profile_tables()`
- diagnostics: `download_finished`, `last_process_engine`,
  `last_process_reason`
- helper workflows: `search_company_names()`, `search_bvd_changes()`,
  `batch_bvd_search()`, `orbis_to_moodys()`

`search_company_names()` uses the Firmographics `bvd_id_and_name` table and an
indexed RapidFuzz matcher. It checks exact matches first, narrows fuzzy
candidates with prefix/token/length blocking, and supports scorer selection,
for example `scorer="token_sort_ratio"` or `scorer="token_set_ratio"`.

Use `Sftp(offline=True)` when you only need packaged metadata and do not want
to log in to the SFTP server. Offline mode supports helpers such as
`search_dictionary()`, `table_dates()`, `search_country_codes()`,
`company_suffix()`, and `offline_capabilities()`.

```python
from moodys_datahub import Sftp

SFTP = Sftp(offline=True, interactive=False)
SFTP.search_dictionary(search_word="revenue")
SFTP.offline_capabilities()
```

By default, `bvd_list` validates values against known country prefixes and a
BvD-like ID pattern. In non-interactive scripts, invalid-looking values raise a
`ValueError`. Set `allow_invalid_bvd_ids=True` to keep them and treat them as
exact IDs:

```python
SFTP = Sftp(interactive=False, allow_invalid_bvd_ids=True)
SFTP.bvd_list = [["custom-id-that-fails-the-format-check"], "bvd_id_number"]
```

`profile_table()` and `profile_tables()` inspect the first file for selected
tables and return a privacy-safe column profile. The report includes dtypes,
missingness, uniqueness, date-format detection, BvD-ID-like value counts, and
operation-readiness hints without exposing source values, examples, top values,
or min/max values.

The BvD-ID heuristic is conservative: it only flags values that look like a
country-code prefix followed by digits, which avoids common name/address false
positives.

```python
profile = SFTP.profile_tables(
    selections={
        "Firmographics (Monthly)": ["bvd_id_and_name"],
        "Ownership": ["linkswitharchive", "beneficial_owners_10_10"],
    },
    save_report=True,
)

print(profile.attrs.get("report_path"))
```

`batch_bvd_search()` uses the workbook-driven `products.xlsx` /
`bvd_numbers.txt` workflow. Optional `AND_bvd_list` and `OR_bvd_list` arguments
apply the same layered BvD filtering model used by `process_all()`.

## Data Files

The package and repository include metadata workbooks under
`src/moodys_datahub/data`:

- `data_dict.xlsx`: broad Moody's DataHub data dictionary. It may include
  products that are not licensed or available in the current SFTP export.
- `data_dict_available.xlsx`: repository workbook with an overview of the data
  products available to the current setup/license. It is intentionally excluded
  from the built wheel unless packaging rules are changed.
- `data_products.xlsx`: packaged product metadata used by the helper loaders.
- `date_cols.xlsx`: known date columns used by date filtering helpers.
- `country_codes.xlsx`: country-code metadata used by country/prefix BvD
  lookup.
- `products.xlsx` and `bvd_numbers.txt`: templates used by
  `batch_bvd_search()`.

## Installation

### Install from a GitHub release wheel

If you want a pinned wheel from a specific GitHub release, install it directly
from the release assets:

```bash
pip install https://github.com/CBS-HPC/moody-s_datahub/releases/download/v1.4.1/moodys_datahub-1.4.1-py3-none-any.whl
```

### Install from a local wheel

Build the package locally and install the wheel from `dist/`:

```bash
python -m build
pip install dist/moodys_datahub-1.4.1-py3-none-any.whl
```

The package pins `paramiko==3.5.1` because the current `pysftp` dependency is
not compatible with newer Paramiko releases. If you install from source, keep
that pin intact unless the SFTP backend is migrated away from `pysftp`.

## Requirements

- Python 3.9+
- Access to a Moody's DataHub SFTP export
- For CBS users: a personal private key (`.pem`) issued for the CBS SFTP setup

## SFTP Access

CBS users should contact CBS staff to obtain a personal private key used to
authenticate against the CBS SFTP server.

For non-CBS SFTP servers, you also need the server `hostname`, `username`, and
the corresponding authentication credentials.

When connecting to an SFTP server, the package detects export folders and tries
to match them to DataHub products automatically. If multiple products share the
same table name, manual selection is required.

## Format Recommendation

Parquet is the recommended export format. It offers the best performance for
large tables because it is compressed, columnar, and typically split into many
smaller file parts.

CSV is supported, but it is often the slowest option and can produce extremely
large single files.

## System Recommendation

Large DataHub tables benefit from high-memory machines. A practical rule of
thumb in this package is roughly 12 GB of memory per worker.

For CBS users, UCloud machines with many cores, high memory, and strong network
throughput are recommended for large exports.

## Getting Started

- [How to get started](https://cbs-hpc.github.io/moody-s_datahub/mkdocs/how_to_get_started/)
- [Git repository](https://github.com/CBS-HPC/moody-s_datahub)
- [API reference](https://cbs-hpc.github.io/moody-s_datahub/mkdocs/api_reference/)

